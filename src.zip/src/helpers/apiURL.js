let apiURLs = {
    SIGNUP_URL: "/api/users",
    LOGIN_URL: "/api/users/login",
    USERDETAIL_URL: "/api/users/me",
    TASK_URL: "/api/tasks",
}

export default apiURLs;